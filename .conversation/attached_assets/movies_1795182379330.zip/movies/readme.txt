# Loop through pages 1169 to 20000 automatically
for ($page = 1169; $page -le 20000; $page++) {
    $uri = "https://yts.pw/api/v2/list_movies.json?page=$page&limit=20000"
    $outFile = "movies_page_$page.json"
    
    Write-Host "Fetching page $page..."
    Invoke-WebRequest -Uri $uri -OutFile $outFile
    
    # Optional: Brief pause to avoid overwhelming the server
    Start-Sleep -Seconds 1
}